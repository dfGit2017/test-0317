package com.demo.user.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.demo.user.bean.User;

@Mapper
public interface UserMapper {

	void addUser(User user);
}
