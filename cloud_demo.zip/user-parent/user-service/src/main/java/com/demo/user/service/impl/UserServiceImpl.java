package com.demo.user.service.impl;

import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.user.bean.Result;
import com.demo.user.bean.User;
import com.demo.user.mapper.UserMapper;
import com.demo.user.service.UserService;
import com.demo.work.bean.Work;
import com.demo.work.service.WorkService;

@RestController
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper userMapper;
	@Autowired
	private WorkService workService;
	
	@Override
	public Result<String> addUser(@RequestBody User user) {
		userMapper.addUser(user);
		
		Work work = new Work();
		work.setDate(new Date());
		Random r = new Random();
		int num = r.nextInt(1000);
		work.setWorkName("workname" + num);
		work.setWorkNo("workno" + num);
		workService.addWork(work);
		
		Result<String> result = new Result<String>();
		result.setCode(0);
		result.setMessage("add user success");
		result.setResult("success");
		result.setData(null);
		return result;
	}
}