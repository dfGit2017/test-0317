package com.demo.user;

import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.demo.user.bean.Result;
import com.demo.user.bean.User;
import com.demo.user.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class UserServiceTest {
	
	@Autowired
	private UserService userService;
	
	@Test
	public void testAddUser() {
		User u = new User();
		Random r = new Random();
		int num = r.nextInt(1000);
		u.setAge(num);
		u.setUsername("username" + num);
		Result<String> result = userService.addUser(u);
		System.out.println(result);
	}
}
