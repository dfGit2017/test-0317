package com.demo.user.service;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.user.bean.Result;
import com.demo.user.bean.User;

@FeignClient("user-service")
public interface UserService {

	@RequestMapping(value = "user/addUser", method = RequestMethod.POST)
	public Result<String> addUser(@RequestBody User user);
	
}
