package com.demo.user.bean;

public class Result<T> {
	
	private int code; 
	private String message; 
	private String result;
	private T data;
	
	public Result() {
		super();
	}
	
	public Result(int code, String message, String result, T data) {
		super();
		this.code = code;
		this.message = message;
		this.result = result;
		this.data = data;
	}
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	
	@Override
	public String toString() {
		return "Result [code=" + code + ", message=" + message + ", result=" + result + ", data=" + data + "]";
	}	
}
