package com.demo.work.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.work.bean.Result;
import com.demo.work.bean.Work;
import com.demo.work.mapper.WorkMapper;
import com.demo.work.service.WorkService;

@RestController
public class WorkServiceImpl implements WorkService {

	@Autowired
	WorkMapper workMapper;

	@Override
	public Result<String> addWork(@RequestBody Work work) {
		workMapper.addWork(work);
		Result<String> result = new Result<String>();
		result.setCode(0);
		result.setMessage("add work success");
		result.setResult("success");
		return result;
	}
	
	
}
