package com.demo.work.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.demo.work.bean.Work;

@Mapper
public interface WorkMapper {
	void addWork(Work work);
}
