package com.demo.work.service;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.work.bean.Result;
import com.demo.work.bean.Work;


@FeignClient("work-service")
public interface WorkService {
	
	@RequestMapping(value = "work/addWork", method = RequestMethod.POST)
	public Result<String> addWork(@RequestBody Work work);
}
