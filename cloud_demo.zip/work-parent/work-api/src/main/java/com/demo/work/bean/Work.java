package com.demo.work.bean;

import java.util.Date;

public class Work {

	private String workNo;
	private String workName;
	private Date date;
	
	public String getWorkNo() {
		return workNo;
	}
	public void setWorkNo(String workNo) {
		this.workNo = workNo;
	}
	public String getWorkName() {
		return workName;
	}
	public void setWorkName(String workName) {
		this.workName = workName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	@Override
	public String toString() {
		return "Work [workNo=" + workNo + ", workName=" + workName + ", date=" + date + "]";
	}
	
}
